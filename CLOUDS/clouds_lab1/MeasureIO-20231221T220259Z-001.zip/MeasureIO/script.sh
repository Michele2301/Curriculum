#!/bin/bash

# Define the paths for Standard SSD and Premium SSD folders
standard_ssd="./standard_ssd"
premium_ssd="./premium_ssd"

# Function to run FIO test
run_fio_test() {
    local folder_path=$1
    local block_size=$2
    local test_name=$3

    fio --directory=$folder_path --name=$test_name --direct=1 --ioengine=libaio --rw=$4 --bs=$block_size --size=1G --numjobs=8 --runtime=60 --group_reporting
}

# Run FIO tests for Standard SSD folder
echo "Running FIO tests for Standard SSD..."
run_fio_test "$standard_ssd" "4k" "random-read-test-standard-ssd" "randread"
run_fio_test "$standard_ssd" "64k" "sequential-test-standard-ssd" "read"

# Run FIO tests for Premium SSD folder
echo "Running FIO tests for Premium SSD..."
run_fio_test "$premium_ssd" "4k" "random-read-test-premium-ssd" "randread"
run_fio_test "$premium_ssd" "64k" "sequential-test-premium-ssd" "read"

